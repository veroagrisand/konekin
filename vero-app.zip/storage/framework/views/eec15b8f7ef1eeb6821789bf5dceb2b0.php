<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'w-full items-center hover:scale-105 transition py-3 bg-purple-900 border text-white border-transparent rounded-md font-medium text-sm uppercase tracking-widest '])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/components/primary-button.blade.php ENDPATH**/ ?>