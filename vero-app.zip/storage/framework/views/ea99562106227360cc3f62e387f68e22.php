<?php echo $__env->make('SuperUser.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content">

      <header class="top-head container-fluid">
          <div class="headaja py-2">
              <?php echo $__env->yieldContent('tittle'); ?>
          </div>
      </header>
      <!-- Header Ends -->

      <div class="warper container-fluid">
        <div class="container">
            <div class="row">
                <div class="col">


                    <div class="page-header">
                        <h3> Users</h3>
                    </div>

                    </div><br />
                    <div class="table-responsive">
                        <table class="table">
                            <tr>
                                
                                <th>Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Birdate</th>
                                <th>Role</th>
                                <th>created_at</th>
                                <th>updated_at</th>

                            </tr>
                       <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $U): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($U->id); ?></td>
                                <td><?php echo e($U->name); ?></td>
                                <td><?php echo e($U->email); ?></td>
                                <td><?php echo e($U->Birthdate); ?></td>
                                <td><?php echo e($U->role); ?></td>
                                <td><?php echo e($U->created_at); ?></td>
                                <td><?php echo e($U->updated_at); ?></td>
                                <td>
                                    
                                    <a  data-toggle="modal" data-target="#modal-hapus<?php echo e($U->id); ?>" class="btn btn-denger"><i class="fas fa-trash-alt">EDIT</i></a>
                                    <a  data-toggle="modal" data-target="#modal-hapus<?php echo e($U->id); ?>" class="btn btn-denger"><i class="fas fa-trash-alt">Hapus</i></a>
                                </td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    </div>
                </div>
            </div>
        </div>
      </div>
      <!-- Warper Ends Here (working area) -->


      <footer class="container-fluid footer">
          Copyright &copy; 2023 <a href="#" >@Konekin</a>
          <a href="#" class="pull-right scrollToTop"><i class="fa fa-chevron-up"></i></a>
      </footer>


  </section>


<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/SuperUser/SUusers.blade.php ENDPATH**/ ?>