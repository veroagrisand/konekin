<?php
    $isJoined = Auth::user()->KEY == $komunitass->KEY || \App\Models\joins::where('id_komunitas', $komunitass->id_komunitas)->where('KEY', auth()->user()->KEY)->exists();
    $Joined =  \App\Models\joins::where('id_komunitas', $komunitass->id_komunitas)->where('KEY', auth()->user()->KEY)->exists();
    $events = \App\Models\kegiatan::where('id_komunitas', $komunitass->id_komunitas)->get();
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
        <div class="container mx-auto mt-10 sm:p-6 md:p-4 p-6">
            <?php echo $__env->make('layouts.partials.H-profilcommunity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($isJoined): ?>

            <div class="grid grid-cols-12 mt-5 flex gap-6 mb-10 flex-row">
                <?php if($events): ?>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Card Container -->
                <div href="#" class="col-span-6 flex flex-row p-2 h-60 bg-white border border-gray-200 rounded-lg items-center transform transition-all hover:-translate-y-2 duration-300">
                  <!-- Image Container -->
                  <div class="w-full h-full">
                    <img class="object-cover w-full h-full rounded" src="<?php echo e(asset ($event->gallery)); ?>" alt="">
                  </div>
                  <!-- Text Content Container -->
                  <div class="flex flex-col top-0 justify-between p-4">
                    <!-- Date and Time Section -->
                    <div class="flex flex-row gap-4 mt-7">
                      <p class="font-bold text-sm text-black"><?php echo e($event->tgl_kegiatan); ?></p>
                      <p class="font-bold text-sm text-black"><?php echo e($event->jam_kegiatan); ?></p>
                    </div>
                    <!-- Title and Description Section -->
                    <div class="mb-7">
                      <h5 class="text-2xl mt-6 font-bold text-black dark:text-white"><?php echo e($event->nama_kegiatan); ?></h5>
                      <p class="font-normal text-slate-900"><?php echo e($event->detail_kegiatan); ?> </p>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>No events found for this community.</p>
                <?php endif; ?>

            </div>
            <?php endif; ?>
        </section>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/layouts/komunitas/event.blade.php ENDPATH**/ ?>