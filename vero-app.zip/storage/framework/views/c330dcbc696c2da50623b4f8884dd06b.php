<style>
    .content {
        margin-bottom: 12%;
        margin-top: 1%; 
    }
</style>
<div class="container py-5 h-100">
            
    <div class="mt-20 jumbo content">
      <h1>Discover Unlimited Potential <br> Within the Community</h1>
      <div class="float-end col-md-4">
        <img src="img/landingpage-image.png" alt="3D" class="img-fluid" width="311px">
      </div>
      <p><strong>Welcome to konekin,</strong> where your vision of a strong community becomes a <br>reality.</p>
      <div class="mt-5 col-md-4 ">
        <a href="/community"><button class="btn" type="button" id="button-addon3">Join Community</button></a>  
      </div>
    </div>

    
    <div class="text-center mb-20">
      <h1>"What communities can you <br>join here?"</h1>
      <p>Discover different communities here! Find one you like, connect with people who share <br>
      your interests, and enjoy a vibrant community experience with us!.</p>
    </div>
  </div><?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/layouts/partials/H-landpage.blade.php ENDPATH**/ ?>