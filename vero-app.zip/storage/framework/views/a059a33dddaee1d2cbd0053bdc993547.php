<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

        <form class="font-poppins" action="<?php echo e(route('createcommunity.create')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="createkomunitas">
            <div class="container py-5">
              <div class="row d-flex justify-content-center  text-white align-items-center">
                  <div class="col-12 col-md-8 col-lg-6 col-xl-9">
                    <p class="justify-center">Create Your Community</p>


                    
                      <div class="card bg-dark text-white">
                          <div class="card-bodyyy ps-2 bg-opacity-25">
                              <div class="row">
                                  <p class="kt mb-5 mt-1 justify-content-center">Category</p>
                                    <div class="dropdown ">
                                      <label for="kategori"></label>
                                      <select class="bg-dark text-white rounded-2" id="kategori" name="id_kategori" required>
                                        <option value=""></option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nama_kategori); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>

        <style>
          #preview {
              max-width: 100%;
              border-radius: 50%; /* Membuat gambar menjadi bulat */
          }
      </style>

      <div class="createkomunitas2">
          <div class="container">
              <div class="row d-flex justify-content-center text-white align-items-center">
                  <div class="col-12 col-md-8 col-lg-6 col-xl-9">
                      <div class="card bg-dark text-white">
                          <div class="card-bodyyy ps-2 mx-auto">
                              <p class="kt">Profile Picture</p>
                              <p class="des text-secondary">Image should be at least 600x600px and in JPEG, JPG, and PNG format.</p>

                              <img id="preview" src="img/konekin-bulat.png" alt="zizan" style="max-width: 100%;">
                              <label for="foto" class="form-label"></label>
                              <input class="form-control form-control-sm bg-dark text-white mb-4 mx-auto" id="foto" type="file" name="image_komunitas" accept="image/*" onchange="previewImage(event)" required>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <script>
          function previewImage(event) {
              var input = event.target;
              var preview = document.getElementById('preview');

              if (input.files && input.files[0]) {
                  var reader = new FileReader();

                  reader.onload = function (e) {
                      preview.src = e.target.result;
                  };

                  reader.readAsDataURL(input.files[0]);
              }
          }
      </script>



        <div class="createkomunitas3 mt-5">
        <div class="container">
          <div class="row d-flex justify-content-center text-white align-items-center" >
              <div class="col-12 col-md-8 col-lg-6 col-xl-9">
                  <div class="card bg-dark text-white">
                      <div class="card-bodyyy ps-2 mx-auto">
                        <p class="kt">About Your Community</p>
                        <div class="mb-4 mx-auto">
                          <input class="form-input col-12 bg-dark" name="nama_komunitas" type="text" id="exampleInputUsername" placeholder="Community Name">
                        </div>
                        <div class="mb-4 mx-auto">
                          <textarea class="form-input col-12 bg-dark" placeholder="Description" name="description_komunitas" id="" required></textarea>
                        </div>

                      </div>
                      <div class="mb-auto mx-auto">
                        <button class="btn btn-light" type="submit">Save</button>
                        </div>
                  </div>
              </div>
          </div>
        </div>
        </div>
        </form>
        <br><br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/layouts/createcommunity.blade.php ENDPATH**/ ?>