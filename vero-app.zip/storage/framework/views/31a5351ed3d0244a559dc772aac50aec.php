<?php
    $isJoined = \App\Models\joins::where('id_komunitas', $komunitass->id_komunitas)->where('KEY', auth()->user()->KEY)->exists();
?>
            <div class="grid grid-cols-12 gap-6">
                <div class="profile-picture-container-community flex col-span-4  w-full item-center sm:ms-auto  ">
                    <img img src="<?php echo e(asset ($komunitass->image_komunitas)); ?>" alt="Profile Picture" class="profile-picture ">
                </div>

                <div class="col-span-8 flex-row gap-2  mt-16 ">
                    <h1 class="sm:ms-10 font-bold font-poppins text-white sm:text-[16px] md:text-[22px] lg:text-[32px]">
                        <?php echo e($komunitass->nama_komunitas); ?>

                        <button id="joinButton" data-community-id="<?php echo e($komunitass->id_komunitas); ?>">
                        <form action="<?php echo e(route('Community.joinS',['id_komunitas'=> $komunitass->id_komunitas])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            
                            
                            <?php if($isJoined): ?>
                                <button type="button" disabled>Joined</button>

                        </form>
                        </button>
                    </h1>
                    <div>
                        <p class="sm:ms-10 font-poppins text-white text-base mt-8 sm:text-[8px] md:text-[10px] lg:text-[14px]"><?php echo e($komunitass->description_komunitas); ?></p>
                    </div>

                    <div class="mt-10 flex-row mb-6">
                        <!-- ... -->
                    </div>
                    <div class="font-poppins  flex space-x-8 sm:text-xs md:text-sm lg:text-base mt-6 items-center mb-6">
                        <div class="hidden sm:-my-px sm:ms-10 sm:flex gap-9">
                           <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => ''.e(route('mycommunity.Event',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => request()->routeIs('mycommunity.Event',['id_komunitas'=> $komunitass->id_komunitas])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('mycommunity.Event',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('mycommunity.Event',['id_komunitas'=> $komunitass->id_komunitas]))]); ?>
                               <?php echo e(__('Event')); ?>

                            <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>

                           <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => ''.e(route('mycommunity.Galery',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => request()->routeIs('mycommunity.Galery',['id_komunitas'=> $komunitass->id_komunitas])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('mycommunity.Galery',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('mycommunity.Galery',['id_komunitas'=> $komunitass->id_komunitas]))]); ?>
                               <?php echo e(__('Galery')); ?>

                            <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>

                           <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => ''.e(route('mycommunity.Forum',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => request()->routeIs('mycommunity.Forum',['id_komunitas'=> $komunitass->id_komunitas])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('mycommunity.Forum',['id_komunitas'=> $komunitass->id_komunitas])).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('mycommunity.Forum',['id_komunitas'=> $komunitass->id_komunitas]))]); ?>
                               <?php echo e(__('Forum')); ?>

                            <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
                       </div>
                   </div>


                </div>
            </div>
            
            <?php else: ?>
            <button type="submit">Join</button>
        <?php endif; ?>
        
<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/layouts/komunitas/navjoin.blade.php ENDPATH**/ ?>