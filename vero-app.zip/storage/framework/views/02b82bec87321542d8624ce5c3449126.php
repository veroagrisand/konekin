<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class=" container mx-auto font-poppins">

  <div class="grid-cols-12 mt-5 flex flex-col ">
    <h1 class="w-auto text-8xl text-center font-semibold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-blue-500">What Communities Can You Join Here?</h1>

        <p class="mt-6 text-center text-lg text-white">Discover different communities here! Find one you like, connect with people who share <br>
        your interests, and enjoy a vibrant community experience with us!.</p>
  </div>
  <div class="text-center mt-12">
          <a href="<?php echo e(route('createcommunity.create')); ?>" class="btncreate badge text-wrap text-center ms-3 me-3"><button class="btn p-2" >Create Community</button></a>
          <a href="<?php echo e(route('mycommunity')); ?>" class="btnmycommunity badge text-wrap text-center ms-3 me-3"><button class="btn p-2" >My Community</button></a>

          

  </div>

  <?php echo $__env->make('layouts.partials.Community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/layouts/community.blade.php ENDPATH**/ ?>