<!-- Start of x-app-layout -->
<?php $user = Auth::user(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <!-- Start of font-poppins section -->
  <section class="font-poppins">
      <!-- Start of container div -->
      <div class="container mx-auto mt-16 sm:p-6 md:p-4 p-6">
          <!-- Start of grid layout -->
          <div class="grid grid-cols-12">
              <!-- Start of left column (col-span-4) -->
              <div class="col-span-4 flex flex-col mx-auto">
                <div class="mb-12">
                    <div>
                        <img src="<?php echo e(asset('' . Auth::user()->avatar)); ?>" style="width: 100px; height: 100px; border-radius: 50%;" alt="<?php echo e(Auth::user()->name); ?>">
                    </div>

                </div>
                <div class="flex flex-col mx-auto gap-8 font-sm">
                    <a href="<?php echo e(route('profile.dasboard')); ?>">
                        <button class="bg-purple-700 text-slate-200 font-md hover:font-md rounded-full w-full py-3 px-4 hover:text-black hover:bg-white forced-colors:appearance-auto" type="button">
                            Dashboard
                        </button>
                    </a>
                    <a href="<?php echo e(route('profile.prifile')); ?>">
                        <button class="bg-purple-700 text-slate-200 font-md hover:font-md rounded-full w-full py-3 px-4 hover:text-black hover:bg-white" type="button">
                            Profile
                        </button>
                    </a>
                    <a href="<?php echo e(route('profile.edit')); ?>">
                        <button class="bg-purple-700 text-slate-200 font-md hover:font-md rounded-full w-full py-3 px-4 hover:text-black hover:bg-white" type="button">
                            Edit profil
                        </button>
                    </a>
                </div>
              </div>
              <!-- Start of right column (col-span-8) -->
              <div class="flex col-span-8 flex-col gap-2">
                  <?php if(Auth::check()): ?>
                      <h2 class="mx-4 mb-0 flex justify-start my-auto" style="color: white;">Hello, <?php echo e(Auth::user()->name); ?></h2>
                      <!-- Start of content section -->
                      <div class="col-8 mt-48 mx-4 my-[150px]">
                          <!-- Example content sections, replace with actual content -->
                          <div class="row gap-20">
                              <div class="row">
                                  <div class="col-4 md-6 mt-4">
                                      <p style="color: white;">Name</p>
                                      <p style="color: white;">Email</p>
                                      <p style="color: white;">Birthday</p>
                                  </div>
                                  <div class="col-4 md-6 mt-4">
                                      <p style="color: white;"><?php echo e(Auth::user()->name); ?> <button></button></p>
                                      <p style="color: white;"><?php echo e(Auth::user()->email); ?></p>
                                      <p style="color: white;"><?php echo e(Auth::user()->Birthdate); ?></p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <!-- Add your additional content here -->
                      <div class="mt-8">
                          <!-- Your additional content goes here -->
                      </div>
                  <?php endif; ?>
              </div>
          </div>
      </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<!-- End of x-app-layout -->
<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/profile/usermyprofile.blade.php ENDPATH**/ ?>