<div class="container mx-auto">
    <div class="grid grid-cols-12">
      <div class="col-span-full overflow-y-auto mt-12 w-full h-[640px] mb-6 flex flex-wrap gap-6 justify-center items-center mx-auto font-poppins">
       
      </div>
    </div>
  </div>


<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/layouts/partials/joinedCommunity.blade.php ENDPATH**/ ?>