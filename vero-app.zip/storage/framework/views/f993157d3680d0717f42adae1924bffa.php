<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

  <!-- Link Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="text-gray-900 antialiased font-poppins">
        <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gradient-to-b from-purple-950 to-slate-950">
            <div>
                <a href="/">
                    
                    
                </a>
            </div>

            <div class="w-full sm:max-w-lg lg:max-w-2xl mt-6 px-6 py-4  border border-1 shadow-md overflow-hidden rounded-lg">
                <?php echo e($slot); ?>

            </div>
        </div>
    </body>

</html>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/layouts/guest.blade.php ENDPATH**/ ?>