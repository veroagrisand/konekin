<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
        <div class="container mx-auto mt-10 sm:p-6 md:p-4 p-6">
            <?php echo $__env->make('layouts.partials.H-profilcommunity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="w-full min-h-screen mb-0 flex-wrap gap-6 flex justify-center items-center mx-auto font-poppins pb-6">
                <!-- Chat Forum Section -->
                <div class="container mx-auto p-8">
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h1 class="text-3xl font-semibold text-slate-700 mb-6">Chat Forum</h1>
                        <?php if($comment && $comment->isNotEmpty()): ?>
                        <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        // Fetch the user based on the email
                        $user = App\Models\User::where('KEY', $C->KEY)->first();
                        ?>
                            <?php if(Auth::user()->KEY == $C->KEY): ?>
                                <div class="justify-end flex items-start mb-4">
                                    <div class="ml-2 text-gray-600"><?php echo e($user->name); ?> | <?php echo e($user->created_at); ?></div>
                                    <div class="ml-2 bg-green-500 text-white p-2 h-10 rounded-md">
                                        <p><?php echo e($C->comment); ?></p>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="justify-start flex items-start mb-4">
                                    <div class="mr-2 bg-purple-900 text-white p-2 rounded-md">
                                        <p><?php echo e($C->comment); ?></p>
                                    </div>
                                    <div class="ml-2 text-gray-600"><?php echo e($user->name); ?> | <?php echo e($user->created_at); ?></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <!-- Comment Section -->
                        <div class="bg-gray-200 mt-6 p-4 rounded-md mb-4 max-h-80 overflow-y-auto">
                            <h2 class="text-2xl font-semibold text-slate-700 mb-4">Chat</h2>
                            <!-- Comment Form -->
                            <form action="<?php echo e(route('mycommunity.ForumAdd', ['id_komunitas' => $komunitass->id_komunitas])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="mb-4">
                                    
                                    <textarea id="content" name="content" rows="4" class="mt-1 p-2 border border-gray-300 rounded-md w-full"></textarea>
                                </div>

                                <div class="flex items-center">
                                    <button type="submit"  class="bg-blue-500 text-white p-2 rounded-md">
                                        
                                            <?php echo e(__('sand')); ?>

                                        
                                    </button>
                                </div>
                            </form>
                        </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\VER LARAVEL\sabalunfinal\vero-app\resources\views/layouts/komunitas/forum.blade.php ENDPATH**/ ?>