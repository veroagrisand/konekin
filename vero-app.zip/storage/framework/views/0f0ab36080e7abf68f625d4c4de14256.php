<?php echo $__env->make('SuperUser.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content">

    <header class="top-head container-fluid">
        <div class="headaja py-2">
            <?php echo $__env->yieldContent('tittle'); ?>
        </div>
    </header>
    <!-- Header Ends -->

    <div class="warper container-fluid">
        <div class="container">
            <div class="row">
                <div class="col">

                    <div class="page-header">
                        <h3> Kelola kegiatan</h3>
                    </div>

                    
                    <br /><br />
                    <div class="alert alert-success" role="alert"></div><br />
                    <div class="table-responsive">
                        <table class="table">
                            <tr>
                                <th>ID kegiatan</th>
                                <th>Nama kegiatan</th>
                                <th>Detail Kegiatan </th>
                                <th>tanggal kegiatan </th>
                                <th>Aksi</th>
                            </tr>

                            <?php if($komunitass): ?>
                                <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $K): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($K->id_komunitas == $komunitass->id_komunitas): ?>
                                        <tr>
                                            <td><?php echo e($K->id_kegiatan); ?></td>
                                            <td><?php echo e($K->nama_kegiatan); ?></td>
                                            <td><?php echo e($K->detail_kegiatan); ?></td>
                                            <td><?php echo e($K->tgl_kegiatan); ?> | <?php echo e($K->jam_kegiatan); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('superuser.edit.kegiatan', ['id_komunitas' => $K->id_komunitas])); ?>" method="get" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary btn-sm btn-edit" onclick="return confirm('Apakah yakin ingin mengedit?');">Edit</button>
                                                </form>
                                                <form action="<?php echo e(route('superuser.hapus.kegiatan', ['id_komunitas' => $K->id_komunitas])); ?>" method="post" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm btn-delete" onclick="return confirm('Apakah yakin ingin menghapus?' );">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">No komunitas found</td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Warper Ends Here (working area) -->

    <footer class="container-fluid footer">
        Copyright &copy; 2023 <a href="#">@Konekin</a>
        <a href="#" class="pull-right scrollToTop"><i class="fa fa-chevron-up"></i></a>
    </footer>

</section>
<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/SuperUser/SUkelolakegiatan.blade.php ENDPATH**/ ?>