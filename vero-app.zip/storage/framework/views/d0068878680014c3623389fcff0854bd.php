
<?php echo $__env->make('SuperUser.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content">

      <header class="top-head container-fluid">
          <div class="headaja py-2">
              <?php echo $__env->yieldContent('tittle'); ?>
          </div>
      </header>
      <!-- Header Ends -->

      <div class="warper container-fluid">
        <div class="container">
            <div class="row">
                <div class="col">

                    <div class="container">
                        <div class="page-header">
                            <h3> Kelola komunitas</h3>
                            <hr>
                        </div>

                        <form action="" class="formkelolakomunitas">

                            <div class="row">
                                <div class="col-3">
                                    <h4>Nama komunitas</h4>
                                </div>
                                <div class="col-3">
                                    <textarea name="namakomunitas" id="namakomunitas" cols="30" rows="3"><?php echo e($komunitass->nama_komunitas); ?> </textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <h4>Deskripsi komunitas</h4>
                                </div>
                                <div class="col-3">
                                    <textarea name="namakomunitas" id="namakomunitas" cols="30" rows="3"><?php echo e($komunitass->description_komunitas); ?></textarea>
                                </div>
                            </div>
                            
                            <div class="row mt-5">
                                <div class="col-3">

                                </div>
                                <div class="col-3">
                                    <button class="btn btn-primary me-1">Simpan</button>
                                    <button class="btn btn-danger">Hapus komunitas</button>
                                </div>
                            </div>
                        </form>

                    </div>


                </div>
            </div>
        </div>
      </div>
      <!-- Warper Ends Here (working area) -->


      <footer class="container-fluid footer">
          Copyright &copy; 2023 <a href="#" >@Konekin</a>
          <a href="#" class="pull-right scrollToTop"><i class="fa fa-chevron-up"></i></a>
      </footer>


  </section>

<?php /**PATH D:\LARAVEL\KONEKIN\finish\vero-app\resources\views/SuperUser/SUkelolakomunitas.blade.php ENDPATH**/ ?>