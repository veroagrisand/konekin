<x-app-layout>
    <section>
        <div class="container mx-auto mt-10 sm:p-6 md:p-4 p-6">
            @include('layouts.komunitas.navjoin')
        </section>
    </x-app-layout>
