@extends('layout.templateuser')

@section('title', 'Createcommunity')

@section('content')
    
<div class="text-center mt-5">
    <h1>Welcome to Your Community</h1>
    <br>
    <p>Create your community</p>
  </div>
<br>

<div class="text-center">
        <a href="/mycommunity" class="btncreate badge text-wrap text-center ms-3 me-3"><button class="btn p-2" >Continue</button></a>
</div>

<br><br><br><br><br>



@stop