@extends('layout.template')

@section('title', 'Contact')

@section('content')
    <h1>Ini Contact</h1>

@stop